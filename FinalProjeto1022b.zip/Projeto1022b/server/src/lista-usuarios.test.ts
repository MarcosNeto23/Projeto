import {test,expect,describe} from 'vitest'
import ListaUsuarios from './lista-usuarios'

test("Deve listar usuarios no banco de dados",async()=>{
    //GIVEN -> DADO ALGO INICIAL
    const listaUsuarios = new ListaUsuarios()
    const ListaPreCadastrada = [
        {
        id: 1,
        nome: 'João',
        idade: 18,
        cpf: '036.547.382-10',
        rg: '002.874.325',
        endereco: 'Rua das flores, Bairro dos Planetas, Número 10, Naviraí - MS',
        estado_civil: 'casado'
        }
    ]
    //WHEN -> QUANDO  EU EXECUTO ALGO
    const usuariosDoBanco = await listaUsuarios.execute()
    //THEN -> EU ESPERO QUE ISSO ACONTECA
    expect(usuariosDoBanco).toEqual(ListaPreCadastrada)
})