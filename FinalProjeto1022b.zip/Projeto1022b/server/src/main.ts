console.log("Felipe é Calvo");

import Express , {Request,Response} from 'express';
import Cors from 'cors';
import ListaUsuarios from './lista-usuarios';
import ListaProdutos from "./lista-produtos";
import InserirProdutos from './inserir-produtos';
const app = Express();

app.use(Cors());
app.use(Express.json())

app.get("/",(req:Request,res:Response)=>{
    res.send("Respondido.").status(200);
})

app.get("/produtos", async (req:Request,res:Response)=>{
    const objListaProdutos = new ListaProdutos();
    const produtos = await objListaProdutos.execute();
    res.send(produtos).status(200);
})

app.get("/usuarios", async (req:Request,res:Response)=>{
    const objListaUsuarios = new ListaUsuarios();
    const usuarios = await objListaUsuarios.execute();
    res.send(usuarios).status(200);
})

app.post("/produtos", async (req:Request,res:Response)=>{
    //Receber os dados para inserir no banco
    //Criar produto recebido pela requisição
    const {id,nome,descricao,preco,imagem} = req.body
    const produto = {id,nome,descricao,preco,imagem}
    const objInserirProdutos = new InserirProdutos()
    try{
    const produtoInserido = await objInserirProdutos.execute(produto)
    res.send(produtoInserido).status(200);
    }catch(e){
        res.status(400).send({mensagem:"Não foi possível cadastrar"})
    }
})

app.listen(8000,()=>{
    console.log("Server rodando na porta 8000")
})

