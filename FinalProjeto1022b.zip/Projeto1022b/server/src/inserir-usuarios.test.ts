import {test,expect, afterEach} from 'vitest'
import ListaUsuarios from './lista-usuarios'
import mysql from 'mysql2/promise';
import 'dotenv/config'
import InserirUsuarios from './inserir-usuarios';


afterEach(async()=>{
    const connection = await mysql.createConnection({
        host: process.env.DB_HOST,
        user: process.env.DB_USER,
        database: process.env.DB_BANCO,
    });
    await connection.query("DELETE FROM usuaros WHERE id=?",[3])
})

test("Deve inserir um produto no banco de dados",async()=>{
    //GIVEN
    const usuario = {
        id: 1,
        nome: "João",
        idade: 18,
        cpf: "036.547.382-10",
        rg: "002.874.325",
        endereco: "Rua das flores, Bairro dos Planetas, Número 10, Naviraí - MS",
        estado_civil: "casado"
    }
    //WHEN  => Quando eu fizer algo.
    const inserirUsuarios = new InserirUsuarios()
    const usuarioDoBanco = await inserirUsuarios.execute(usuario)
    //THEN
    const listaUsuarios = new ListaUsuarios()
    const listaBanco = await listaUsuarios.execute()
    expect(usuarioDoBanco).toEqual(usuario)
    expect(listaBanco).toContainEqual(usuario)
})