console.log("Felipe é Calvo");

import Express , {Request,Response} from 'express';

import ListaUsuarios from './lista-usuarios';
import ListaProdutos from "./lista-produtos";
const app = Express();

app.get("/",(req:Request,res:Response)=>{
    res.send("Respondido.").status(200);
})

app.get("/produtos", async (req:Request,res:Response)=>{
    const objListaProdutos = new ListaProdutos();
    const produtos = await objListaProdutos.execute();
    res.send(produtos).status(200);
})


app.get("/usuarios", async (req:Request,res:Response)=>{
    const objListaUsuarios = new ListaUsuarios();
    const usuarios = await objListaUsuarios.execute();
    res.send(usuarios).status(200);
})

app.listen(8000,()=>{
    console.log("Server rodando na porta 8000")
})

