import {test,expect,describe} from 'vitest'
import ListaProdutos from './lista-produtos'

test("Deve listar produtos do banco de dados",async()=>{
    //GIVEN -> DADO ALGO INICIAL
    const listaProdutos = new ListaProdutos()
    const LIstaPreCadastrada = [
        {
        id: 1,
        nome: 'Iphone',
        descricao: 'Celular RUIM',
        preco: 5000.50,
        imagem: 'SEM IMAGEM'
        },
        {
        id: 2,
        nome: 'Moto G',
        descricao: 'Celular Bom',
        preco: 799.99,
        imagem: 'SEM IMAGEM'
        }
    ]
    //WHEN -> QUANDO  EU EXECUTO ALGO
    const produtosDoBanco = await listaProdutos.execute()
    //THEN -> EU ESPERO QUE ISSO ACONTECA
    expect(produtosDoBanco).toEqual(LIstaPreCadastrada)
})