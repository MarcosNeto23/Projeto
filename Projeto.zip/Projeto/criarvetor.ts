function criaNovoVetor(a:number, b:number,c:number):number{
    return a*b*c
}
export{criaNovoVetor}