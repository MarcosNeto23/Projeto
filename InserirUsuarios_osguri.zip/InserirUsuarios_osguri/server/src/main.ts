console.log("É os Guri, integrantes: Felipe Brito, Marcos Antonio e Mateus do Prado");

import Express , {Request,Response} from 'express';
import Cors from 'cors';
import ListaUsuarios from './lista-usuarios';
import ListaProdutos from "./lista-produtos";
import InserirProdutos from './inserir-produtos';
import InserirUsuarios from './inserir-usuarios';
const app = Express();

app.use(Cors());
app.use(Express.json())

app.get("/",(req:Request,res:Response)=>{
    res.send("Respondido.").status(200);
})

app.get("/produtos", async (req:Request,res:Response)=>{
    const objListaProdutos = new ListaProdutos();
    const produtos = await objListaProdutos.execute();
    res.send(produtos).status(200);
})

app.get("/usuarios", async (req:Request,res:Response)=>{
    const objListaUsuarios = new ListaUsuarios();
    const usuarios = await objListaUsuarios.execute();
    res.send(usuarios).status(200);
})

app.post("/produtos", async (req:Request,res:Response)=>{
    const {id,nome,descricao,preco,imagem} = req.body
    //Esse produto tem que ser igual ao do fetch
    const produto = {id,nome,descricao,preco,imagem}
    const objInserirProdutos = new InserirProdutos()
    try{
        const produtoInserido = await objInserirProdutos.execute(produto)
        res.status(201).send(produtoInserido);
    }catch(e:any){
        console.log(e)
        res.status(400).send({mensagem:"Não foi possível cadastrar ERRO: "+e.message});
    }
})

app.post("/usuarios", async (req:Request,res:Response)=>{
    const {id,nome,idade,cpf,rg,endereco,estado_civil} = req.body
    const usuario = {id,nome,idade,cpf,rg,endereco,estado_civil}
    const objInserirUsuarios = new InserirUsuarios()
    try{
        const usuarioInserido = await objInserirUsuarios.execute(usuario)
        res.status(201).send(usuarioInserido);
    }catch(e:any){
        console.log(e)
        res.status(400).send({mensagem:"Não foi possível cadastrar ERRO: "+e.message});
    }
})

app.listen(8000,()=>{
    console.log("Server rodando na porta 8000")
})

