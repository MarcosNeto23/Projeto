/**
 * Exercício 01 - cria um novo vetor com os valores do vetor original mais dois novos valores
 * Nome da função - criaNovoVetor
 * Crie uma função que retorne um novo vetor com os valores do vetor original mais dois novos valores
 * @param {number[]} vetor Vetor de números
 * @param {number} valor1 Primeiro valor a ser adicionado
 * @param {number} valor2 Segundo valor a ser adicionado
 * @returns {number[]} Retorna um novo vetor com os valores do vetor original mais dois novos valores
 * @example
 * criaNovoVetor([1, 2, 3], 4, 5) // [1, 2, 3, 4, 5]
 * criaNovoVetor([1, 2, 3], 0, 0) // [1, 2, 3, 0, 0]
 */ 

//Início do seu código
function criaNovoVetor(vetor:number[],valor1:number,valor2:number){
    let novoVetor:number[] =[]
    for(let i = 0;i<vetor.length;i++){
        novoVetor.push(vetor[i])
    }
    novoVetor.push(valor1)
    novoVetor.push(valor2)
    return novoVetor
}
export{criaNovoVetor}
//Fim do seu código