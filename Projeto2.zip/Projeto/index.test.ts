import {test, expect} from 'vitest';

test("Primeiro teste", ()=>{
    expect(2).toBe(2)
})


//Exercicio1
import {criaNovoVetor} from './criarvetor'
test('criaNovoVetor com os novos dois valores passados', () => {
    let vetor = [1, 2, 3]
    expect(criaNovoVetor(vetor, 4, 5)).toEqual([1, 2, 3, 4, 5])
    expect(vetor).toEqual([1, 2, 3])
})
test('criaNovoVetor com os novos dois valores passados', () => {
    let vetor = [1, 2, 3]
    expect(criaNovoVetor(vetor, 0, 0)).toEqual([1, 2, 3, 0, 0])
    expect(vetor).toEqual([1, 2, 3])
})

//Exercicio 2