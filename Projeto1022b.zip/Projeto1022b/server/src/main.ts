console.log("Felipe é Calvo");
import mysql from 'mysql2/promise';



// Create the connection to database

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  database: 'banco1022b',
});
connection
.then()//se deu certo
.catch((erro)=>{
    if(erro.code==='ECONNREFUSED'){
        console.log("LIGA O LARAGON")
    }else{
        console.log(erro)
    }
    if(erro.code==='ER_BAD_DB_ERROR'){
    console.log("BANCO DE DADOS NÃO EXISTE")
    }
})//se deu errado